.. _cyl:

Equidistant Cylindrical Projection
==================================

The simplest projection, just displays the world in latitude/longitude coordinates. 

.. literalinclude:: figures/cyl.py

.. image:: figures/cyl.png
