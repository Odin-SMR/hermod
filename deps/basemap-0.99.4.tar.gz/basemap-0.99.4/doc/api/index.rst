.. _api-index:

####################################
  The Matplotlib Basemap Toolkit API
####################################

:Release: |version|
:Date: |today|

.. toctree::

    basemap_api.rst
