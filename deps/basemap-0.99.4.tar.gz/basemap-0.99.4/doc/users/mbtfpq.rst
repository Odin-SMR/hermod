.. _mbtfpq:

McBryde-Thomas Flat Polar Quartic
=================================

A global equal-area projection.

.. literalinclude:: figures/mbtfpq.py

.. image:: figures/mbtfpq.png
