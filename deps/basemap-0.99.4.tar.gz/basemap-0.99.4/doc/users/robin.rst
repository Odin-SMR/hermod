.. _robin:

Robinson Projection
===================

A global projection once used by the National Geographic Society for world maps.

.. literalinclude:: figures/robin.py

.. image:: figures/robin.png
