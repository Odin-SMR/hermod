# Runs the test cases that have been developed for GEOS

require 'test_envelope'
require 'test_geom'
require 'test_io'
require 'test_operations'
require 'test_relations'
require 'test_combinations'
