.. _moll:

Mollweide Projection
====================

The mollweide projection is a global, elliptical, equal-area projection.  

.. literalinclude:: figures/moll.py

.. image:: figures/moll.png
