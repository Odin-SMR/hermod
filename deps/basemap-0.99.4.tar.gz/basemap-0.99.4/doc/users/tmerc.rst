.. _tmerc:

Transverse Mercator Projection
==============================

The transverse aspect of the mercator projection.
The globe is first rotated so the central meridian becomes the "equator",
and then the normal mercator projection is applied.

.. literalinclude:: figures/tmerc.py

.. image:: figures/tmerc.png
