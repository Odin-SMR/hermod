.. _gnomon:

Gnomonic Projection
===================

In the gnomonic projection, great circles are straight lines.

.. literalinclude:: figures/gnomon.py

.. image:: figures/gnomon.png
