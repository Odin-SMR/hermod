.. _merc:

Mercator Projection
===================

A cylindrical, conformal projection.  Very large distortion at high latitudes, cannot fully reach the polar regions.

.. literalinclude:: figures/merc.py

.. image:: figures/merc.png
