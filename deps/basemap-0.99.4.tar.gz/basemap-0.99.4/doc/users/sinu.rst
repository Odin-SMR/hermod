.. _sinu:

Sinusoidal Projection
=====================

A global equal-area projection where the length of each parallel is
equal to the cosine of the latitude.

.. literalinclude:: figures/sinu.py

.. image:: figures/sinu.png
