/**********************************************************************
 * $Id: PolygonizeEdge.cpp,v 1.3 2004/10/19 19:51:14 strk Exp $
 *
 * GEOS - Geometry Engine Open Source
 * http://geos.refractions.net
 *
 * Copyright (C) 2001-2002 Vivid Solutions Inc.
 *
 * This is free software; you can redistribute and/or modify it under
 * the terms of the GNU Lesser General Public Licence as published
 * by the Free Software Foundation. 
 * See the COPYING file for more information.
 *
 **********************************************************************/


#include <geos/opPolygonize.h>

namespace geos {

PolygonizeEdge::PolygonizeEdge(const LineString *newLine) {
	line=newLine;
}

const LineString *
PolygonizeEdge::getLine() {
	return line;
}

}

/**********************************************************************
 * $Log: PolygonizeEdge.cpp,v $
 * Revision 1.3  2004/10/19 19:51:14  strk
 * Fixed many leaks and bugs in Polygonizer.
 * Output still bogus.
 *
 * Revision 1.2  2004/07/02 13:28:29  strk
 * Fixed all #include lines to reflect headers layout change.
 * Added client application build tips in README.
 *
 * Revision 1.1  2004/04/08 04:53:56  ybychkov
 * "operation/polygonize" ported from JTS 1.4
 *
 *
 **********************************************************************/
