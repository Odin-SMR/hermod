.. _poly:

Polyconic Projection
====================

.. literalinclude:: figures/poly.py

.. image:: figures/poly.png
