.. _geos:

Geostationary Projection
========================

The geostationary projection displays the earth as a satellite 
(in geostationary orbit) would see it.

.. literalinclude:: figures/geos_full.py

.. image:: figures/geos_full.png

.. literalinclude:: figures/geos_partial.py

.. image:: figures/geos_partial.png
