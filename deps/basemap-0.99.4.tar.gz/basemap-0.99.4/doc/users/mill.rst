.. _mill:

Miller Cylindrical Projection
=============================

A modified version of the mercator projection that avoids the polar
singularity.  Neither equal-area or conformal.

.. literalinclude:: figures/mill.py

.. image:: figures/mill.png
