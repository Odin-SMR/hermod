.. _users-guide-index:

#############################################
  The Matplotlib Basemap Toolkit User's Guide
#############################################

:Release: |version|
:Date: |today|

.. toctree::

    intro.rst
    installing.rst
    mapsetup.rst
    geography.rst
    graticule.rst
