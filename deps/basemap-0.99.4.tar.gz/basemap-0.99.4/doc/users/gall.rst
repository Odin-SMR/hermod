.. _gall:

Gall Stereographic Projection
=============================

A stereographic, cylindrical projection that is neither equal-area
or conformal.

.. literalinclude:: figures/gall.py

.. image:: figures/gall.png
