.. _cass:

Cassini Projection
==================

The transverse aspect of the equidistant cassindrical projection.
The globe is first rotated so the central meridian becomes the "equator",
and then the normal equidistant cylindrical projection is applied.

.. literalinclude:: figures/cass.py

.. image:: figures/cass.png
